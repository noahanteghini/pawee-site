# PAWÉ — site vitrine

Site de présentation statique. Pour le publier gratuitement avec GitHub Pages :
1. Décompressez l’archive.
2. Téléversez `index.html` à la racine du dépôt GitHub.
3. Dans Settings > Pages, choisissez Deploy from a branch, `main`, `/(root)`, puis Save.

Ce site est une vitrine de présentation : il ne prend pas de commandes et ne collecte aucun paiement.
